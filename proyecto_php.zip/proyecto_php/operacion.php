﻿<?php
if (\['REQUEST_METHOD'] == 'POST') {
    \ = \['num1'] ?? 0;
    \ = \['num2'] ?? 0;
    \ = \['operacion'] ?? '';
    
    switch (\) {
        case 'suma':
            \ = \ + \;
            break;
        case 'resta':
            \ = \ - \;
            break;
        case 'multiplicacion':
            \ = \ * \;
            break;
        case 'division':
            \ = \ != 0 ? \ / \ : 'Error: División por cero';
            break;
        default:
            \ = 'Operación no válida';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Operaciones Matemáticas</title>
    <link rel='stylesheet' href='css/operacion.css'>
</head>
<body>
    <form method="post">
        <input type="number" name="num1" required>
        <select name="operacion">
            <option value="suma">Suma</option>
            <option value="resta">Resta</option>
            <option value="multiplicacion">Multiplicación</option>
            <option value="division">División</option>
        </select>
        <input type="number" name="num2" required>
        <button type="submit">Calcular</button>
    </form>
    <?php if (isset(\)) : ?>
        <p>Resultado: <?php echo \; ?></p>
    <?php endif; ?>
</body>
</html>
