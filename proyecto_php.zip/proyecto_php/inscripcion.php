﻿<?php
if (\['REQUEST_METHOD'] == 'POST') {
    \ = \['nombre'] ?? '';
    \ = \['email'] ?? '';
    \ = \['descripcion'] ?? '';
    \ = \['opcion'] ?? '';
    \ = \['intereses'] ?? [];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Inscripción</title>
    <link rel='stylesheet' href='css/inscripcion.css'>
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <label>Nombre:</label>
        <input type="text" name="nombre" required>
        <label>Email:</label>
        <input type="email" name="email" required>
        <label>Descripción:</label>
        <textarea name="descripcion" maxlength="300" required></textarea>
        <label>Opción:</label>
        <select name="opcion">
            <option value="opcion1">Opción 1</option>
            <option value="opcion2">Opción 2</option>
        </select>
        <label>Intereses:</label>
        <input type="checkbox" name="intereses[]" value="deporte"> Deporte
        <input type="checkbox" name="intereses[]" value="musica"> Música
        <input type="checkbox" name="intereses[]" value="lectura"> Lectura
        <button type="submit">Inscribirse</button>
    </form>
    <?php if (\['REQUEST_METHOD'] == 'POST') : ?>
        <p>Nombre: <?php echo htmlspecialchars(\); ?></p>
        <p>Email: <?php echo htmlspecialchars(\); ?></p>
        <p>Descripción: <?php echo htmlspecialchars(\); ?></p>
        <p>Opción seleccionada: <?php echo htmlspecialchars(\); ?></p>
        <p>Intereses: <?php echo implode(", ", \); ?></p>
    <?php endif; ?>
</body>
</html>
