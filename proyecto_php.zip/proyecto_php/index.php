﻿<!DOCTYPE html>
<html lang='es'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Proyecto PHP</title>
    <link rel='stylesheet' href='css/style.css'>
</head>
<body>
    <h1>Bienvenido al Proyecto PHP</h1>
    <ul>
        <li><a href='and_or_xor.php'>Puertas Lógicas</a></li>
        <li><a href='encriptar.php'>Encriptar Mensaje</a></li>
        <li><a href='desencriptar.php'>Desencriptar Mensaje</a></li>
        <li><a href='estadisticas.php'>Cálculo Estadístico</a></li>
        <li><a href='operacion.php'>Operaciones Matemáticas</a></li>
        <li><a href='inscripcion.php'>Inscripción</a></li>
    </ul>
</body>
</html>
